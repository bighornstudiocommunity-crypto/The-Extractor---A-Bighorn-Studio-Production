﻿namespace GardeningAppWinForms
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Panel topBar;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.TextBox searchBox;
        private System.Windows.Forms.Button searchButton;
        private System.Windows.Forms.Button settingsButton;
        private System.Windows.Forms.Button contactButton;
        private System.Windows.Forms.Button AboutButton;
        private System.Windows.Forms.Button donateButton;
        private System.Windows.Forms.Button chatButton;
        private System.Windows.Forms.RichTextBox resultBox;
        private System.Windows.Forms.ListBox suggestionsList;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();

            // Top bar
            this.topBar = new System.Windows.Forms.Panel();
            this.topBar.BackColor = System.Drawing.Color.FromArgb(30, 30, 30);
            this.topBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.topBar.Height = 72;

            // Title label
            this.titleLabel = new System.Windows.Forms.Label();
            this.titleLabel.Text = "The Extractor";
            this.titleLabel.ForeColor = System.Drawing.Color.White;
            this.titleLabel.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.titleLabel.AutoSize = true;
            this.titleLabel.Location = new System.Drawing.Point(16, 18);
            this.topBar.Controls.Add(this.titleLabel);

            // Search box (placed under top bar)
            this.searchBox = new System.Windows.Forms.TextBox();
            this.searchBox.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.searchBox.Location = new System.Drawing.Point(24, 92);
            this.searchBox.Size = new System.Drawing.Size(560, 29);
            this.searchBox.Name = "searchBox";

            // Search button
            this.searchButton = new System.Windows.Forms.Button();
            this.searchButton.Text = "🔍 Search";
            this.searchButton.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.searchButton.Location = new System.Drawing.Point(600, 90);
            this.searchButton.Size = new System.Drawing.Size(110, 34);
            this.searchButton.BackColor = System.Drawing.Color.SeaGreen;
            this.searchButton.ForeColor = System.Drawing.Color.White;
            this.searchButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.searchButton.Click += new System.EventHandler(this.searchButton_Click);

            // Settings button (in top bar, right)
            this.settingsButton = new System.Windows.Forms.Button();
            this.settingsButton.Text = "⚙";
            this.settingsButton.Font = new System.Drawing.Font("Segoe UI Emoji", 12F, System.Drawing.FontStyle.Bold);
            this.settingsButton.Location = new System.Drawing.Point(780, 18);
            this.settingsButton.Size = new System.Drawing.Size(40, 36);
            this.settingsButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.settingsButton.BackColor = System.Drawing.Color.Transparent;
            this.settingsButton.ForeColor = System.Drawing.Color.White;
            this.topBar.Controls.Add(this.settingsButton);

            // Contact button (in top bar)
            this.contactButton = new System.Windows.Forms.Button();
            this.contactButton.Text = "✉";
            this.contactButton.Font = new System.Drawing.Font("Segoe UI Emoji", 12F, System.Drawing.FontStyle.Bold);
            this.contactButton.Location = new System.Drawing.Point(730, 18);
            this.contactButton.Size = new System.Drawing.Size(40, 36);
            this.contactButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.contactButton.BackColor = System.Drawing.Color.Transparent;
            this.contactButton.ForeColor = System.Drawing.Color.White;
            this.topBar.Controls.Add(this.contactButton);

            // Donate button (in top bar)
            this.donateButton = new System.Windows.Forms.Button();
            this.donateButton.Text = "💖";
            this.donateButton.Font = new System.Drawing.Font("Segoe UI Emoji", 12F, System.Drawing.FontStyle.Bold);
            this.donateButton.Location = new System.Drawing.Point(680, 18);
            this.donateButton.Size = new System.Drawing.Size(40, 36);
            this.donateButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.donateButton.BackColor = System.Drawing.Color.Transparent;
            this.donateButton.ForeColor = System.Drawing.Color.White;
            this.topBar.Controls.Add(this.donateButton);

            // About button (in top bar)
            this.AboutButton = new System.Windows.Forms.Button();
            this.AboutButton.Text = "?";
            this.AboutButton.Font = new System.Drawing.Font("Segoe UI Emoji", 12F, System.Drawing.FontStyle.Bold);
            this.AboutButton.Location = new System.Drawing.Point(630, 18);
            this.AboutButton.Size = new System.Drawing.Size(40, 36);
            this.AboutButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AboutButton.BackColor = System.Drawing.Color.Transparent;
            this.AboutButton.ForeColor = System.Drawing.Color.White;
            this.topBar.Controls.Add(this.AboutButton);

            // Chat button (below top bar, right)
            this.chatButton = new System.Windows.Forms.Button();
            this.chatButton.Text = "Community Chat";
            this.chatButton.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular);
            this.chatButton.Location = new System.Drawing.Point(720, 90);
            this.chatButton.Size = new System.Drawing.Size(190, 34);
            this.chatButton.BackColor = System.Drawing.Color.FromArgb(70, 130, 180);
            this.chatButton.ForeColor = System.Drawing.Color.White;
            this.chatButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chatButton.Click += new System.EventHandler(this.chatButton_Click);

            // Result box (main center)
            this.resultBox = new System.Windows.Forms.RichTextBox();
            this.resultBox.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.resultBox.Location = new System.Drawing.Point(24, 140);
            this.resultBox.Size = new System.Drawing.Size(886, 320);
            this.resultBox.ReadOnly = true;
            this.resultBox.BackColor = System.Drawing.Color.WhiteSmoke;

            // Suggestions list (bottom)
            this.suggestionsList = new System.Windows.Forms.ListBox();
            this.suggestionsList.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.suggestionsList.Location = new System.Drawing.Point(24, 470);
            this.suggestionsList.Size = new System.Drawing.Size(886, 90);

            // Form
            this.ClientSize = new System.Drawing.Size(940, 600);
            this.Controls.Add(this.topBar);
            this.Controls.Add(this.searchBox);
            this.Controls.Add(this.searchButton);
            this.Controls.Add(this.chatButton);
            this.Controls.Add(this.resultBox);
            this.Controls.Add(this.suggestionsList);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "The Extractor";
            this.topBar.ResumeLayout(false);
            this.topBar.PerformLayout();
        }
    }
}
