using System;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GardeningAppWinForms
{
    public partial class Form1 : Form
    {
        private static readonly HttpClient client = new HttpClient();

        // thème actuel
        private string currentTheme = "Dark";

        public Form1()
        {
            InitializeComponent();

            try { client.DefaultRequestHeaders.Add("User-Agent", "GardeningAppWinForms/1.0"); } catch { }

            // événements
            this.searchBox.KeyDown += SearchBox_KeyDown;
            this.suggestionsList.DoubleClick += SuggestionsList_DoubleClick;
            this.settingsButton.Click += SettingsButton_Click;
            this.contactButton.Click += ContactButton_Click;
            this.donateButton.Click += DonateButton_Click;
        }

        // =========================
        // Recherche
        // =========================
        private async void searchButton_Click(object sender, EventArgs e)
        {
            await DoSearchAsync();
        }

        private async void SearchBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                await DoSearchAsync();
            }
        }

        private async void SuggestionsList_DoubleClick(object sender, EventArgs e)
        {
            if (suggestionsList.SelectedItem is string sel && !string.IsNullOrWhiteSpace(sel))
            {
                searchBox.Text = sel;
                await DoSearchAsync();
            }
        }

        private async Task DoSearchAsync()
        {
            string query = (searchBox.Text ?? "").Trim();
            if (string.IsNullOrEmpty(query))
            {
                MessageBox.Show("Please enter a plant name.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            resultBox.Text = "Searching...";
            suggestionsList.Items.Clear();

            string url = $"https://en.wikipedia.org/api/rest_v1/page/summary/{Uri.EscapeDataString(query)}";

            try
            {
                using var resp = await client.GetAsync(url);
                if (resp.IsSuccessStatusCode)
                {
                    string json = await resp.Content.ReadAsStringAsync();
                    using var doc = JsonDocument.Parse(json);
                    if (doc.RootElement.TryGetProperty("extract", out var extract))
                    {
                        string description = extract.GetString() ?? "No description available.";
                        resultBox.Text = $"🌱 {query}\n\n{Summarize(description)}";
                        return;
                    }
                }

                // si pas trouvé → suggestions
                await LoadSuggestionsAsync(query);
            }
            catch (Exception ex)
            {
                resultBox.Text = $"Error: {ex.Message}";
            }
        }

        private async Task LoadSuggestionsAsync(string query)
        {
            try
            {
                string url = $"https://en.wikipedia.org/w/api.php?action=opensearch&search={Uri.EscapeDataString(query)}&limit=6&namespace=0&format=json";
                using var resp = await client.GetAsync(url);
                if (!resp.IsSuccessStatusCode)
                {
                    resultBox.Text = $"No results found for \"{query}\".";
                    return;
                }

                string json = await resp.Content.ReadAsStringAsync();
                using var doc = JsonDocument.Parse(json);
                if (doc.RootElement.GetArrayLength() >= 2)
                {
                    var arr = doc.RootElement[1];
                    if (arr.GetArrayLength() == 0)
                    {
                        resultBox.Text = $"No results found for \"{query}\".";
                        return;
                    }

                    resultBox.Text = $"No exact page for \"{query}\". Suggestions:";
                    suggestionsList.Items.Clear();
                    foreach (var it in arr.EnumerateArray())
                    {
                        string s = it.GetString() ?? "";
                        suggestionsList.Items.Add(s);
                        resultBox.AppendText($"\n- {s}");
                    }
                }
                else
                {
                    resultBox.Text = $"No results found for \"{query}\".";
                }
            }
            catch (Exception ex)
            {
                resultBox.Text = $"Error loading suggestions: {ex.Message}";
            }
        }

        private string Summarize(string text, int maxSentences = 3)
        {
            if (string.IsNullOrWhiteSpace(text)) return text;
            var parts = text.Split(new[] { '.' }, StringSplitOptions.RemoveEmptyEntries);
            int n = Math.Min(parts.Length, maxSentences);
            var outLines = new System.Collections.Generic.List<string>();
            for (int i = 0; i < n; i++)
            {
                string s = parts[i].Trim();
                if (!string.IsNullOrEmpty(s)) outLines.Add("• " + s + ".");
            }
            return string.Join("\n", outLines);
        }

        // =========================
        // Autres boutons
        // =========================
        private void chatButton_Click(object sender, EventArgs e)
        {
            try
            {
                var chat = new ChatForm();
                chat.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to open chat: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SettingsButton_Click(object sender, EventArgs e)
        {
            var settings = new SettingsForm(this, 0, "None", currentTheme);
            settings.ShowDialog();
        }

        private void ContactButton_Click(object sender, EventArgs e)
        {
            var contact = new ContactForm();
            contact.ShowDialog();
        }

private void AboutButton_Click(object sender, EventArgs e)
        {
            
            MessageBox.Show("V 2.2.1 - Chat bug : I will fix it later \n - Give us feedback \n (not released yet) : V 2.2.2 - Chat bug fix \n More personalized themes \n (not released yet) : V 2.3.0 - Extension \n Developed by Bighorn Studio");
        }

        private void DonateButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Donate feature will be available in v2.1.0", "Donate", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // =========================
        // Gestion des thèmes
        // =========================
        public void ApplyTheme(string theme)
        {
            if (string.IsNullOrWhiteSpace(theme)) return;
            currentTheme = theme;

            string t = theme.Trim().ToLowerInvariant();

            try
            {
                if (t.Contains("dark"))
                {
                    this.BackColor = System.Drawing.Color.FromArgb(30, 30, 30);
                    if (topBar != null) topBar.BackColor = System.Drawing.Color.FromArgb(20, 20, 20);
                    if (resultBox != null) { resultBox.BackColor = System.Drawing.Color.WhiteSmoke; resultBox.ForeColor = System.Drawing.Color.Black; }
                    if (suggestionsList != null) suggestionsList.BackColor = System.Drawing.Color.White;
                    if (searchButton != null) { searchButton.BackColor = System.Drawing.Color.MediumSeaGreen; searchButton.ForeColor = System.Drawing.Color.White; }
                }
                else if (t.Contains("purple"))
                {
                    this.BackColor = System.Drawing.Color.FromArgb(40, 0, 60);
                    if (topBar != null) topBar.BackColor = System.Drawing.Color.FromArgb(30, 0, 50);
                    if (resultBox != null) { resultBox.BackColor = System.Drawing.Color.FromArgb(245, 240, 250); resultBox.ForeColor = System.Drawing.Color.Black; }
                    if (suggestionsList != null) suggestionsList.BackColor = System.Drawing.Color.FromArgb(250, 245, 255);
                    if (searchButton != null) { searchButton.BackColor = System.Drawing.Color.MediumPurple; searchButton.ForeColor = System.Drawing.Color.White; }
                }
                else // Light
                {
                    this.BackColor = System.Drawing.Color.FromArgb(245, 245, 245);
                    if (topBar != null) topBar.BackColor = System.Drawing.Color.FromArgb(230, 230, 230);
                    if (resultBox != null) { resultBox.BackColor = System.Drawing.Color.White; resultBox.ForeColor = System.Drawing.Color.Black; }
                    if (suggestionsList != null) suggestionsList.BackColor = System.Drawing.Color.White;
                    if (searchButton != null) { searchButton.BackColor = System.Drawing.Color.SeaGreen; searchButton.ForeColor = System.Drawing.Color.White; }
                }
            }
            catch
            {
                // ignore erreurs si un contrôle est manquant
            }
        }
    }
}
