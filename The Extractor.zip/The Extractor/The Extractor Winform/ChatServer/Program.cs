using System;
using System.Windows.Forms;

namespace GardeningAppWinForms
{
    internal static class Program
    {
        /// <summary>
        /// Point d’entrée principal de l’application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // Initialisation standard WinForms
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Lancer le formulaire principal
            Application.Run(new Form1());
        }
    }
}
