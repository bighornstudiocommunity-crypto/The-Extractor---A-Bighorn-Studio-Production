using System;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.AspNetCore.SignalR.Client;

namespace GardeningAppWinForms
{
    public partial class ChatForm : Form
    {
        private HubConnection connection;

        public ChatForm()
        {
            InitializeComponent();
            // lance la connexion en tâche de fond
            _ = InitSignalRAsync();
        }

        private async Task InitSignalRAsync()
        {
            // adresse du serveur SignalR (change si besoin)
            var url = "http://localhost:5000/chatHub";

            connection = new HubConnectionBuilder()
                .WithUrl(url)
                .WithAutomaticReconnect()
                .Build();

            // réception des messages
            connection.On<string, string>("ReceiveMessage", (user, message) =>
            {
                // on est peut-être sur un thread non-UI => Invoke si nécessaire
                if (chatBox.InvokeRequired)
                {
                    chatBox.Invoke(new Action(() =>
                    {
                        chatBox.AppendText($"{user}: {message}{Environment.NewLine}");
                    }));
                }
                else
                {
                    chatBox.AppendText($"{user}: {message}{Environment.NewLine}");
                }
            });

            try
            {
                await connection.StartAsync();
                chatBox.AppendText("Connected to chat server.\n");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to connect to server: {ex.Message}", "Connection error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void sendButton_Click(object sender, EventArgs e)
        {
            if (connection == null || connection.State != HubConnectionState.Connected)
            {
                MessageBox.Show("Not connected to chat server.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string user = (userBox.Text ?? "Anon").Trim();
            string message = (messageBox.Text ?? "").Trim();
            if (string.IsNullOrEmpty(message)) return;

            try
            {
                await connection.InvokeAsync("SendMessage", user, message);
                messageBox.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Send failed: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // nettoie la connexion proprement quand la fenêtre se ferme
        protected override async void OnFormClosing(FormClosingEventArgs e)
        {
            if (connection != null)
            {
                try
                {
                    await connection.StopAsync();
                    await connection.DisposeAsync();
                }
                catch { /* ignore */ }
            }
            base.OnFormClosing(e);
        }
    }
}
