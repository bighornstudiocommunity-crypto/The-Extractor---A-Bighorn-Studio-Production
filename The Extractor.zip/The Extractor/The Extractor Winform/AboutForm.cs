using System;
using System.Drawing;
using System.Windows.Forms;

namespace GardeningAppWinForms
{
    public class AboutForm : Form
    {
        public AboutForm()
        {
            this.Text = "Learn more about us !";
            this.Size = new Size(700, 800);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.BackColor = Color.White;

            Label label = new Label();
            label.Text = "V 2.2.1 - Chat bug : I will fix it later \n - Give us feedback \n (not released yet) : V 2.2.2 - Chat bug fix \n More personalized themes \n (not released yet) : V 2.3.0 - Extension \n Developed by Bighorn Studio";
            label.Font = new Font("Bree Serif", 12F);
            label.AutoSize = true;
            label.Location = new Point(30, 50);

            this.Controls.Add(label);
        }
    }
}
