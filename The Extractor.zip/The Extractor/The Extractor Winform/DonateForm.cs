using System;
using System.Drawing;
using System.Windows.Forms;

namespace GardeningAppWinForms
{
    public class DonateForm : Form
    {
        public DonateForm()
        {
            this.Text = "Donate now !";
            this.Size = new Size(400, 200);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.BackColor = Color.White;

            Label label = new Label();
            label.Text = "This page hasn't been implemented yet.";
            label.Font = new Font("Bree Serif", 12F);
            label.AutoSize = true;
            label.Location = new Point(30, 50);

            this.Controls.Add(label);
        }
    }
}
