using System;
using System.Drawing;
using System.Windows.Forms;

namespace GardeningAppWinForms
{
    public partial class SettingsForm : Form
    {
        private Form1 mainForm;

        public SettingsForm(Form1 form, int totalSearches, string favorite, string theme)
        {
            InitializeComponent();
            mainForm = form;

            lblStats.Text = $"Total searches: {totalSearches}\nFavorite research : {favorite}";
            comboTheme.Items.AddRange(new[] { "Dark", "Light", "Purple" });
            comboTheme.SelectedItem = theme;
        }

        private void btnApply_Click(object sender, EventArgs e)
        {
            mainForm.ApplyTheme(comboTheme.SelectedItem.ToString());
            this.Close();
        }
    }
}
