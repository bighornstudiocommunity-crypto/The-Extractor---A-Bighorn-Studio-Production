namespace GardeningAppWinForms
{
    partial class ChatForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.RichTextBox chatBox;
        private System.Windows.Forms.TextBox messageBox;
        private System.Windows.Forms.TextBox userBox;
        private System.Windows.Forms.Button sendButton;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.chatBox = new System.Windows.Forms.RichTextBox();
            this.messageBox = new System.Windows.Forms.TextBox();
            this.userBox = new System.Windows.Forms.TextBox();
            this.sendButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // chatBox
            // 
            this.chatBox.Location = new System.Drawing.Point(12, 12);
            this.chatBox.Name = "chatBox";
            this.chatBox.ReadOnly = true;
            this.chatBox.Size = new System.Drawing.Size(360, 200);
            this.chatBox.TabIndex = 0;
            this.chatBox.Text = "";
            // 
            // messageBox
            // 
            this.messageBox.Location = new System.Drawing.Point(12, 250);
            this.messageBox.Name = "messageBox";
            this.messageBox.Size = new System.Drawing.Size(280, 20);
            this.messageBox.TabIndex = 1;
            // 
            // userBox
            // 
            this.userBox.Location = new System.Drawing.Point(12, 220);
            this.userBox.Name = "userBox";
            this.userBox.Size = new System.Drawing.Size(280, 20);
            this.userBox.TabIndex = 2;
            this.userBox.Text = "Username";
            // 
            // sendButton
            // 
            this.sendButton.Location = new System.Drawing.Point(300, 250);
            this.sendButton.Name = "sendButton";
            this.sendButton.Size = new System.Drawing.Size(75, 23);
            this.sendButton.TabIndex = 3;
            this.sendButton.Text = "Send";
            this.sendButton.UseVisualStyleBackColor = true;
            this.sendButton.Click += new System.EventHandler(this.sendButton_Click);
            // 
            // ChatForm
            // 
            this.ClientSize = new System.Drawing.Size(384, 291);
            this.Controls.Add(this.sendButton);
            this.Controls.Add(this.userBox);
            this.Controls.Add(this.messageBox);
            this.Controls.Add(this.chatBox);
            this.Name = "ChatForm";
            this.Text = "Community Chat";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
