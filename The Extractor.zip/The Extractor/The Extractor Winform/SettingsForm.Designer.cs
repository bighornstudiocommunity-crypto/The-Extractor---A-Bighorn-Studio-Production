namespace GardeningAppWinForms
{
    partial class SettingsForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label lblStats;
        private System.Windows.Forms.Label lblTheme;
        private System.Windows.Forms.ComboBox comboTheme;
        private System.Windows.Forms.Button btnApply;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblStats = new System.Windows.Forms.Label();
            this.lblTheme = new System.Windows.Forms.Label();
            this.comboTheme = new System.Windows.Forms.ComboBox();
            this.btnApply = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblStats
            // 
            this.lblStats.AutoSize = true;
            this.lblStats.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblStats.Location = new System.Drawing.Point(20, 20);
            this.lblStats.Name = "lblStats";
            this.lblStats.Size = new System.Drawing.Size(101, 19);
            this.lblStats.TabIndex = 0;
            this.lblStats.Text = "User statistics...";
            // 
            // lblTheme
            // 
            this.lblTheme.AutoSize = true;
            this.lblTheme.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblTheme.Location = new System.Drawing.Point(20, 80);
            this.lblTheme.Name = "lblTheme";
            this.lblTheme.Size = new System.Drawing.Size(52, 19);
            this.lblTheme.TabIndex = 1;
            this.lblTheme.Text = "Theme:";
            // 
            // comboTheme
            // 
            this.comboTheme.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboTheme.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.comboTheme.FormattingEnabled = true;
            this.comboTheme.Location = new System.Drawing.Point(90, 77);
            this.comboTheme.Name = "comboTheme";
            this.comboTheme.Size = new System.Drawing.Size(150, 25);
            this.comboTheme.TabIndex = 2;
            // 
            // btnApply
            // 
            this.btnApply.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnApply.Location = new System.Drawing.Point(170, 130);
            this.btnApply.Name = "btnApply";
            this.btnApply.Size = new System.Drawing.Size(90, 30);
            this.btnApply.TabIndex = 3;
            this.btnApply.Text = "Apply";
            this.btnApply.UseVisualStyleBackColor = true;
            this.btnApply.Click += new System.EventHandler(this.btnApply_Click);
            // 
            // SettingsForm
            // 
            this.ClientSize = new System.Drawing.Size(300, 180);
            this.Controls.Add(this.btnApply);
            this.Controls.Add(this.comboTheme);
            this.Controls.Add(this.lblTheme);
            this.Controls.Add(this.lblStats);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SettingsForm";
            this.Text = "⚙ Settings";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
