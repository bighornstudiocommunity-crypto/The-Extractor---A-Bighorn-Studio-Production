using System;
using System.Windows.Forms;

namespace GardeningAppWinForms
{
    // IMPORTANT : "partial" pour correspondre au Designer partiel
    public partial class ContactForm : Form
    {
        public ContactForm()
        {
            InitializeComponent();
        }
    }
}

