ReadMe :
To Launch the app : follow the Following path into the directory tree :
 - The Extractor
    --> The Extractor Winform
         --> Bin 
             --> Release
                 --> net9.0-windows
                     --> And here you can launch the extractor with "The Extractor" ( exe file )